CREATE DATABASE  IF NOT EXISTS `addmission_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `addmission_db`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: addmission_db
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `degree_details`
--

DROP TABLE IF EXISTS `degree_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `degree_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stid` varchar(45) NOT NULL,
  `hsc` varchar(100) NOT NULL,
  `ssc` varchar(145) NOT NULL,
  `cet` varchar(145) NOT NULL,
  `adhar` varchar(135) NOT NULL,
  `verify_status` varchar(20) DEFAULT 'pending',
  `fees_status` varchar(50) DEFAULT '45000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `degree_details`
--

LOCK TABLES `degree_details` WRITE;
/*!40000 ALTER TABLE `degree_details` DISABLE KEYS */;
INSERT INTO `degree_details` VALUES (1,'2','StudentDocumentsDegree/2/hsc_image_Screenshot (25).png','StudentDocumentsDegree/2/ssc_image_Screenshot (13).png','StudentDocumentsDegree/2/cet_image_Screenshot (23).png','StudentDocumentsDegree/2/adhar_image_Screenshot (18).png','Verified','45000'),(2,'4','StudentDocumentsDegree/4/hsc_image_Card_Pay.jpeg','StudentDocumentsDegree/4/ssc_image_LogIn.png','StudentDocumentsDegree/4/cet_image_IssueBook.png','StudentDocumentsDegree/4/adhar_image_IssueBook.png','Verified','25000'),(3,'5','StudentDocumentsDegree/5/hsc_image_certificate.png','StudentDocumentsDegree/5/ssc_image_food.png','StudentDocumentsDegree/5/cet_image_shopping-cart.png','StudentDocumentsDegree/5/adhar_image_facebooklogo3.jpeg-removebg-preview.png','Verified','20000'),(4,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(5,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(6,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(7,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(8,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(9,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(10,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(11,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(12,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(13,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(14,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(15,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(16,'6','StudentDocumentsDegree/6/hsc_image_BookServlet.png','StudentDocumentsDegree/6/ssc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/cet_image_RegisterUser.png','StudentDocumentsDegree/6/adhar_image_BookServlet.png','Verified','25000'),(17,'6','StudentDocumentsDegree/6/hsc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/ssc_image_IssuedAndReturnStatusTable.png','StudentDocumentsDegree/6/cet_image_addBook.PNG','StudentDocumentsDegree/6/adhar_image_DisplayBookAndCheckbox.png','Verified','25000'),(18,'6','StudentDocumentsDegree/6/hsc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/ssc_image_IssuedAndReturnStatusTable.png','StudentDocumentsDegree/6/cet_image_addBook.PNG','StudentDocumentsDegree/6/adhar_image_DisplayBookAndCheckbox.png','Verified','25000'),(19,'6','StudentDocumentsDegree/6/hsc_image_DisplayUserDetails.png','StudentDocumentsDegree/6/ssc_image_IssuedAndReturnStatusTable.png','StudentDocumentsDegree/6/cet_image_addBook.PNG','StudentDocumentsDegree/6/adhar_image_DisplayBookAndCheckbox.png','Verified','25000'),(20,'6','StudentDocumentsDegree/6/hsc_image_IssuedAndReturnStatusTable.png','StudentDocumentsDegree/6/ssc_image_RegisterUser.png','StudentDocumentsDegree/6/cet_image_swati Biodata.pdf','StudentDocumentsDegree/6/adhar_image_IssueBook.png','Verified','45000'),(21,'1','StudentDocumentsDegree/1/hsc_image_IssuedAndReturnStatusTable.png','StudentDocumentsDegree/1/ssc_image_DisplayBookAndCheckbox.png','StudentDocumentsDegree/1/cet_image_addBook.PNG','StudentDocumentsDegree/1/adhar_image_LogIn.png','pending','-15000');
/*!40000 ALTER TABLE `degree_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-11 21:17:04
